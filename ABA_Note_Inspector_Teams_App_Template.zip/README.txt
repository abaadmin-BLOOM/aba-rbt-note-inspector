ABA Note Inspector - Microsoft Teams App Package

IMPORTANT:
This Teams package cannot run your HTML/CSS/JS files by itself. Microsoft Teams tab apps require a secure HTTPS-hosted URL.

Before uploading:
1. Host index.html, styles.css, and app.js in a secure approved location.
2. Open manifest.json.
3. Replace every instance of:
   https://YOUR-SECURE-HOSTED-URL
   with your real secure hosted URL.
4. Replace validDomains entry with only the domain, for example:
   happkiddos.com
5. Zip ONLY these three files:
   manifest.json
   color.png
   outline.png
6. Upload the zip in Teams under Apps > Manage your apps > Upload an app.

HIPAA/PHI WARNING:
Do not use public or unauthenticated hosting if staff will enter client names, diagnoses, session details, Medicaid data, or caregiver information.
